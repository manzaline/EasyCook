create view EMP_VIEW30 as
SELECT empno,ename,deptno FROM emp_copy WHERE deptno=101
/

