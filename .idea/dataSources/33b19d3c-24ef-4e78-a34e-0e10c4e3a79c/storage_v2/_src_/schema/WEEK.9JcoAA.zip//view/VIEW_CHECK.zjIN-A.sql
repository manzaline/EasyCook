create view VIEW_CHECK as
select empno,ename,deptno from emp86 where deptno=20 with check option
/

