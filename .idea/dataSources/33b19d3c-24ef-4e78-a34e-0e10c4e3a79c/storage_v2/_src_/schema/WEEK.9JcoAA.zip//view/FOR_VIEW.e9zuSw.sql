create view FOR_VIEW as
select empno,ename from abc
/

