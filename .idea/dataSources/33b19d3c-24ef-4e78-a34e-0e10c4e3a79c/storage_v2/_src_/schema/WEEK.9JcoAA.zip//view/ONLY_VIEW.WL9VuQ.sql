create view ONLY_VIEW as
select empno,ename,sal,comm,deptno from emp86 where deptno=20 with read only
/

