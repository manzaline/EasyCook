create view RE_VIEW as
select empno,ename,sal from emp86
/

