create view JOIN_VIEW as
SELECT empno,ename,job,sal,comm,d.deptno,dname,LOC FROM dept86 d,emp86 e WHERE d.deptno=e.deptno
AND e.deptno=10 ORDER BY empno asc
/

