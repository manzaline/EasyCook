create view ROW_VIEW as
SELECT empno,ename,sal FROM emp92 ORDER BY empno DESC
/

